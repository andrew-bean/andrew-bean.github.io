# 04_model.R
# Functions for regression modelling

gapminder_fit_linear_models <- function(candidate_models, data = health_data){

    # Hint: use lapply() with FUN = lm
  model_fits <- lapply(candidate_models, lm, data = health_data)
  return(model_fits)
  
}
