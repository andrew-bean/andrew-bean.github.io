# 05_predict.R
# Functions for prediction and inference using regression models

gapminder_predict_with_all_models <- function(model_fits, new_data) {
  
  # Get predictions from each model
  pred <- lapply(model_fits, predict, newdata = new_data, interval = "confidence")
  pred_df <- lapply(pred, \(x) as.data.frame(x) |> mutate(country_id = 1:nrow(new_data)))
  
  # Combine all predictions
  all_predictions <- bind_rows(
    pred_df, .id = "model"
  ) |>
    left_join(
      new_data |> mutate(country_id = 1:nrow(new_data)),
      by = "country_id"
    )
  
  
}

gapminder_prediction_plot <- function(predictions) {
  
  ggplot(predictions, aes(x = model, y = fit, color = continent)) +
    geom_point(size = 3, position = position_dodge(width = 0.5)) +
    geom_errorbar(aes(ymin = lwr, ymax = upr),
                  width = 0.2,
                  position = position_dodge(width = 0.5)) +
    facet_wrap(~country_type) +
    labs(title = "Predicted Life Expectancy by Model and Country Type",
         x = "Model",
         y = "Predicted Life Expectancy (years)") +
    theme_minimal()
}