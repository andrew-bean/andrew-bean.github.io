# 01_prepare_data.R
# Functions for loading and preparing data

gapminder_prepare_data <- function(year) {

  data(gapminder)
  health_data <- gapminder |>
    filter(year == !!year) |>
    mutate(
      log_gdp = log10(gdpPercap),
      log_pop = log10(pop)
    )
  
}
