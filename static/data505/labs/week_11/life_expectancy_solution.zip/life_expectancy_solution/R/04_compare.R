# 04_compare.R
# Functions for comparing models

gapminder_compare_models <- function(model_fits) {
  
  # Hint: use do.call() with FUN = anova
  do.call(anova, unname(model_fits))
  
}