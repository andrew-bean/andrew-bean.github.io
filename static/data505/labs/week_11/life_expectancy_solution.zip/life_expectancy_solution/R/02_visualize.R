# 02_visualize.R
# Functions for creating visualizations

gapminder_plot_life_vs_gdp <- function(health_data, log_scale = TRUE) {
  
  p_base <- # With log scale (log_scale = TRUE)
    ggplot(health_data, aes(x = gdpPercap, y = lifeExp)) +
    geom_point(aes(color = continent), size = 2, alpha = 0.6) +
    geom_smooth(method = "lm", color = "black", se = TRUE) +
    theme_minimal()
  
  if(log_scale){
    p <- p_base + 
      scale_x_log10() +
      labs(title = "Life Expectancy vs. GDP per Capita (Log Scale)",
           x = "GDP per Capita (USD, log scale)",
           y = "Life Expectancy (years)",
           color = "Continent")
  } else{
    p <- p_base + 
      labs(title = "Life Expectancy vs. GDP per Capita",
           x = "GDP per Capita (USD)",
           y = "Life Expectancy (years)",
           color = "Continent")
  }
  
  return(p)
  
}
