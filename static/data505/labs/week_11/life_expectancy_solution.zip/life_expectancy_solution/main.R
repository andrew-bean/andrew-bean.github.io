# main.R
# Main pipeline script for country average life-expectancy analysis
# This script executes the analysis workflow

# Ensure the current working directory is as expected
here::i_am("main.R")
library(here)

# Load required packages
library(dplyr)
library(tibble)
library(ggplot2)
library(gapminder)

# Source all function files
source("R/01_prepare_data.R")
source("R/02_visualize.R")
source("R/03_model.R")
source("R/04_compare.R")
source("R/05_predict.R")

# Step 1: load and prepare the data --------------------------------------------

health_data <- gapminder_prepare_data(year = 2007)


# Step 2: Create and save visualizations ---------------------------------------

plot_log <- gapminder_plot_life_vs_gdp(health_data, log_scale = TRUE)
plot <- gapminder_plot_life_vs_gdp(health_data, log_scale = FALSE)
ggsave(plot_log, filename = here("output", "life_expectancy_vs_log_gdp.png"))
ggsave(plot, filename = here("output", "life_expectancy_vs_gdp.png"))


# Step 3: Fit models -----------------------------------------------------------

candidate_models <- list(
  model1 = lifeExp ~ log_gdp,
  model2 = lifeExp ~ log_gdp + continent,
  model3 = lifeExp ~ log_gdp + continent + log_pop
)
model_fits <- gapminder_fit_linear_models(candidate_models)


# Step 4: F-test for model comparison and selection of best model --------------

model_comparison <- gapminder_compare_models(model_fits)
model_comparison


# Step 5: inference for mean life expectancy -----------------------------------

new_countries <- read.csv(here("data", "new_countries.csv"))
new_country_means <- gapminder_predict_with_all_models(model_fits, new_countries)


# Save and visualize the predictions
write.csv(new_country_means, file = here("output", "predictions.csv"))
prediction_plot <- gapminder_prediction_plot(new_country_means)
ggsave(prediction_plot, filename = here("output", "prediction_plot.png"))
