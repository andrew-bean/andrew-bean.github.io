# 01_prepare_data.R
# Functions for loading and preparing data

gapminder_prepare_data <- function(...) {

}
