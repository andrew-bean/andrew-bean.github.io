# 02_visualize.R
# Functions for creating visualizations

gapminder_plot_life_vs_gdp <- function(...) {
  
}
