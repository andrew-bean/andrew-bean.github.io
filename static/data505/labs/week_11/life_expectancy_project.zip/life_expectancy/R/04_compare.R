# 04_compare.R
# Functions for comparing models

gapminder_compare_models <- function(...) {
  
  # Hint: use do.call() with FUN = anova
  
}