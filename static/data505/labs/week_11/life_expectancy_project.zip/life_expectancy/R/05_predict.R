# 05_predict.R
# Functions for prediction and inference using regression models

gapminder_predict_with_all_models <- function(model_fits, new_data) {
  
}

gapminder_prediction_plot <- function(predictions) {
  
}