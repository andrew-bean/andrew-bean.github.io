# 04_model.R
# Functions for regression modelling

gapminder_fit_linear_models <- function(...){

    # Hint: use lapply() with FUN = lm
  
}
