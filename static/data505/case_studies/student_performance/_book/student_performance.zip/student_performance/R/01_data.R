# NOTE: ALL FUNCTIONS IN THIS SCRIPT ARE PROVIDED FOR YOU

#' Read raw math data
#' @param path character path to CSV (default: data/raw/student-mat.csv)
#' @return data.frame with raw types
read_student_mat <- function(path = here::here("data", "raw", "student-mat.csv")) {
	read.csv(path, sep = ";", stringsAsFactors = FALSE)
}

#' Apply reasonable variable types (factors, ordered factors, integers)
#' @param df data.frame of raw student-mat
#' @return tibble with coerced types
coerce_types <- function(df) {
	# Helpers for ordered scales
	ord_1_4 <- function(x, labels) ordered(x, levels = 1:4, labels = labels)
	ord_1_5 <- function(x, labels) ordered(x, levels = 1:5, labels = labels)

		df |>
			mutate(
			# Schools, demographics, family context
			school   = factor(school, levels = c("GP","MS"),
												labels = c("Gabriel Pereira","Mousinho da Silveira")),
			sex      = factor(sex, levels = c("F","M"), labels = c("Female","Male")),
			age      = as.integer(age),
			address  = factor(address, levels = c("U","R"), labels = c("Urban","Rural")),
			famsize  = factor(famsize, levels = c("LE3","GT3"), labels = c("≤3"," >3")),
			Pstatus  = factor(Pstatus, levels = c("T","A"), labels = c("together","apart")),

			# Parental education (0..4) as ordered factors
			Medu = ordered(Medu, levels = 0:4,
										 labels = c("none","primary(4th)","5th-9th","secondary","higher")),
			Fedu = ordered(Fedu, levels = 0:4,
										 labels = c("none","primary(4th)","5th-9th","secondary","higher")),

			# Occupations and school choice context
			Mjob = factor(Mjob),
			Fjob = factor(Fjob),
			reason = factor(reason),
			guardian = factor(guardian),

			# Study/commute burden (1..4 ordered)
			traveltime = ord_1_4(traveltime, labels = c("<15m","15-30m","30-60m",">1h")),
			studytime  = ord_1_4(studytime,  labels = c("<2h","2-5h","5-10h",">10h")),

			# Performance history and binary supports
			failures = as.integer(failures),
			schoolsup = factor(schoolsup, levels = c("no","yes")),
			famsup    = factor(famsup, levels = c("no","yes")),
			paid      = factor(paid, levels = c("no","yes")),
			activities= factor(activities, levels = c("no","yes")),
			nursery   = factor(nursery, levels = c("no","yes")),
			higher    = factor(higher, levels = c("no","yes")),
			internet  = factor(internet, levels = c("no","yes")),
			romantic  = factor(romantic, levels = c("no","yes")),

			# 1..5 scales as ordered
			famrel   = ord_1_5(famrel, labels = c("very bad","bad","average","good","excellent")),
			freetime = ord_1_5(freetime, labels = c("very low","low","medium","high","very high")),
			goout    = ord_1_5(goout, labels = c("very low","low","medium","high","very high")),
			Dalc     = ord_1_5(Dalc, labels = c("very low","low","medium","high","very high")),
			Walc     = ord_1_5(Walc, labels = c("very low","low","medium","high","very high")),
			health   = ord_1_5(health, labels = c("very bad","bad","average","good","very good")),

			# Absences and grades
			absences = as.integer(absences),
			G1 = as.integer(G1),
			G2 = as.integer(G2),
			G3 = as.integer(G3)
		) |>
		tibble::as_tibble()
}

#' Save derived dataset to RDA
#' @param df data.frame/tibble to save
#' @param path output path (default: data/derived/student_performance.rda)
save_derived <- function(df, path = here::here("data", "derived", "student_performance.rda")) {
	outdir <- dirname(path)
	if (!dir.exists(outdir)) dir.create(outdir, recursive = TRUE)
	student_performance <- df
	save(student_performance, file = path)
	invisible(path)
}

