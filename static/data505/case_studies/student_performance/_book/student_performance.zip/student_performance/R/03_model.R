# Basic modelling helpers (keep minimal)

#' Fit a basic regression model (1–2 predictors)
#' Uses absences to explain final grade G3.
#' @param df data frame with variables G3, G2, absences
#' @return lm object
fit_basic_model <- function(df){
	d <- df |>
		dplyr::select(dplyr::all_of(c("G3","absences"))) |>
		stats::na.omit()
	lm(G3 ~ absences, data = d)
}

#' (TODO: FOR YOU TO COMPLETE)
#' Stepwise variable selection using MASS::stepAIC
#' Implement forward/backward selection on a small candidate set.
#' @param df data frame
#' @param direction "forward" | "backward" | "both"
#' @return lm object (selected), or NULL until implemented
run_stepwise <- function(df, direction = "both"){
	# TODO: Implement with MASS::stepAIC
	# Hints:
	#   d <- df |>
	#        dplyr::select(G3, G2, G1, absences, failures, studytime) |>
	#        stats::na.omit()
	#   start <- stats::lm(G3 ~ 1, data = d)
	#   scope <- stats::formula(G3 ~ G2 + G1 + absences + failures + studytime)
	#   MASS::stepAIC(start, scope = list(lower = ~1, upper = scope), direction = direction)
	warning("run_stepwise() not yet implemented. See hints in 03_model.R.")
	invisible(NULL)
}

