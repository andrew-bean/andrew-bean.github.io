# Exploratory analysis helper functions

#' Summarize outcomes (grades)
#' THIS FUNCTION IS COMPLETED FOR YOU AS AN EXAMPLE
#' Summarize numeric grade-related variables
#' Returns a tibble with mean, sd, min, q1, median, q3, max for G1, G2, G3.
summarize_grades <- function(df) {
	df |>
		tidyr::pivot_longer(c(G1, G2, G3), names_to = "grade", values_to = "value") |>
		group_by(grade) |>
		summarise(
			n = dplyr::n(),
			mean = mean(value, na.rm = TRUE),
			sd = sd(value, na.rm = TRUE),
			min = min(value, na.rm = TRUE),
			q1 = quantile(value, 0.25, na.rm = TRUE),
			median = median(value, na.rm = TRUE),
			q3 = quantile(value, 0.75, na.rm = TRUE),
			max = max(value, na.rm = TRUE),
			.groups = "drop"
		)
}

#' Plot relationship between study time and final grade
#' Produces a concise boxplot of G3 across studytime categories.
plot_studytime_vs_grade <- function(df) {
		ggplot(df, aes(x = factor(studytime), y = G3)) +
		geom_boxplot(outlier.alpha = 0.35, fill = '#3A9848') +
		labs(x = "Study time category", y = "Final grade (G3)",
				 title = "G3 distribution across study time categories") +
		theme_minimal()
}

# ---------- Your turn (incomplete "skeleton" functions) ----------

#' Summarize final grade by school (mean, sd, n)
summarize_by_school <- function(df) {
	# TODO: implement grouping by school and summarizing G3
	# Example starter:
	# df |> group_by(school) |> summarize(mean_G3 = mean(G3), sd_G3 = sd(G3), n = n())
	
	# delete the warning and replace the return value with your implementation
	warning("summarize_by_school() not yet implemented")
	return(invisible(NULL))
}

#' Correlation heatmap for selected numeric predictors
#' (STUDENT TODO) Choose a subset of numeric columns (e.g., G1,G2,G3,absences,failures,Dalc,Walc) and plot correlation matrix.
correlation_plot <- function(df) {
	# TODO: select numeric columns, compute correlation, reshape, and plot with geom_tile()
	# Hints: use select(), cor(), as.data.frame(), tidyr::pivot_longer()/pivot_wider or reshape2::melt
	
	# delete the warning and replace the return value with your implementation
	warning("correlation_plot() not yet implemented")
	return(invisible(NULL))
}

# ---------- Suggested extensions (open-ended) ----------
# * Function to compare grade distributions by failures count
# * Function to visualize relationship between absences and G3 (scatter with smoothing)
# * Function to tabulate alcohol consumption (Dalc/Walc) vs G3 quartiles
# * Function to explore parental education (Medu/Fedu) vs final grade

