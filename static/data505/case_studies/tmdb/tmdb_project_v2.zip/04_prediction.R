# 04_prediction.R
# Name: 
# Date: 
# Drew University DATA 505 Fall 2025
#
# Assignment:
# Build the best predictive model you can for log_revenue using multiple linear
# regression. You will make predictions on a test set and submit them for 
# evaluation. The pair with the lowest RMSE (root mean squared error) wins!
#
# Submission requirements:
# 1. During class: Submit predictions as CSV files (format specified below)
#    - You may submit multiple times to improve your score
#    - Each submission will be evaluated and posted to the leaderboard
# 2. End of class: Submit your final R script on Moodle under Case Study 1 
#    Box Office Analysis (Part 4)
#
# Purpose:
# - Practice building and evaluating multiple linear regression models
# - Learn to balance model complexity with predictive performance
# - Experience a realistic prediction challenge with held-out test data

here::i_am("04_prediction.R")
library(here)

# Load required packages
suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
})

# 1. Load the training data ----------------------------------------------------

# This is the same cleaned dataset from Part 1, which will serve as your
# training data for building models
movies_train <- readRDS(here("data", "movies_clean.rds"))

cat("Training data loaded:", nrow(movies_train), "movies\n")
cat("Available predictors:\n")
print(names(movies_train))

# 2. Explore the training data -------------------------------------------------

# Before building models, it's important to understand your data.
# You should have done a lot of this work during part 3 of the 
# case study. Here are a few explorations:

# Summary statistics
summary(movies_train)

# Distribution of the outcome variable
ggplot(movies_train, aes(x = log_revenue)) +
  geom_histogram(bins = 30, fill = "steelblue", color = "white") +
  labs(title = "Distribution of Log Revenue (Training Data)",
       x = "Log Revenue", y = "Count") +
  theme_minimal()

# Relationship between budget and revenue
ggplot(movies_train, aes(x = budget, y = log_revenue)) +
  geom_point(alpha = 0.5) +
  geom_smooth(method = "lm", se = TRUE, color = "red") +
  labs(title = "Budget vs Log Revenue",
       x = "Budget ($)", y = "Log Revenue") +
  theme_minimal()

# Add more exploratory plots as needed!


# 3. Helper function: Calculate RMSE -------------------------------------------

# Root Mean Squared Error - lower is better!
calculate_rmse <- function(actual, predicted) {
  sqrt(mean((actual - predicted)^2))
}


# 4. Baseline Model 1: Simple linear regression --------------------------------

# Let's start with a simple model using only budget as a predictor

model_1 <- lm(log_revenue ~ budget, data = movies_train)
summary(model_1)

# Evaluate on training data
predictions_train_1 <- predict(model_1, newdata = movies_train)
rmse_train_1 <- calculate_rmse(movies_train$log_revenue, predictions_train_1)
cat("Model 1 Training RMSE:", round(rmse_train_1, 4), "\n")


# 5. Baseline Model 2: Multiple predictors -------------------------------------

# Now let's add more predictors

model_2 <- lm(log_revenue ~ budget + vote_average, 
              data = movies_train)
summary(model_2)

# Evaluate on training data
predictions_train_2 <- predict(model_2, newdata = movies_train)
rmse_train_2 <- calculate_rmse(movies_train$log_revenue, predictions_train_2)
cat("Model 2 Training RMSE:", round(rmse_train_2, 4), "\n")

# Notice: Did adding more predictors improve the model?


# 6. Example: Model with categorical predictor ---------------------------------

# You can also include categorical variables like production_company_origin_country
# R will automatically create dummy variables for you

model_3 <- lm(log_revenue ~ budget + runtime + production_company_origin_country, 
              data = movies_train)
summary(model_3)

predictions_train_3 <- predict(model_3, newdata = movies_train)
rmse_train_3 <- calculate_rmse(movies_train$log_revenue, predictions_train_3)
cat("Model 3 Training RMSE:", round(rmse_train_3, 4), "\n")


# 7. Tips for improving your model ---------------------------------------------

# Here are some strategies to consider:
#
# a) Feature engineering: creating new predictors from the existing set. For
#    example:
#    - Create interaction terms, e.g.: budget * vote_average
#    - Transform variables: log(budget), sqrt(runtime)
#    - Extract year from release_date: as.numeric(format(release_date, "%Y"))
#    - Create binary indicators: is_popular <- popularity > median(popularity)
#
# b) Feature selection:
#    - Not all variables improve prediction
#    - Some variables might be correlated (multicollinearity)
#    - Try different combinations and compare RMSE
#
# c) Model diagnostics:
#    - Check residual plots: plot(model)
#    - Look for patterns that suggest non-linearity
#    - Check for influential outliers
#
# d) Avoid overfitting:
#    - More complex models may fit training data better but perform worse on test data
#    - Balance model complexity with generalizability

# Example: Adding a year variable
movies_train <- movies_train |>
  mutate(release_year = as.numeric(format(release_date, "%Y")))

# Example: Interaction term
model_4 <- lm(log_revenue ~ budget + vote_average + budget:vote_average, 
              data = movies_train)
summary(model_4)


# 8. YOUR TURN: Build your best model -----------------------------------------

# Now it's your turn! Experiment with different model specifications.
# Try to minimize the RMSE on the test set (which you'll see when you submit).

# Some ideas to explore:
# - Which predictors are most important?
# - Should you include interactions?
# - Should you transform any variables?
# - Should you include release_year?

## YOUR CODE HERE - Build your final model

# Example template (replace with your own model):
# my_final_model <- lm(log_revenue ~ ..., data = movies_train)
# summary(my_final_model)


# 9. Load test data and make predictions ---------------------------------------

# Load the test dataset (this has the same structure but different movies)
# NOTE: The test data does NOT include log_revenue, revenue, title, or overview
# to prevent you from looking up the actual values

movies_test <- readRDS(here("data", "movies_test.rds"))

cat("\nTest data loaded:", nrow(movies_test), "movies\n")

# IMPORTANT: If you created any new variables in the training data (like 
# release_year), you must create them in the test data too!

# Example:
movies_test <- movies_test |>
  mutate(release_year = as.numeric(format(release_date, "%Y")))


# Make predictions using your final model
# Replace 'my_final_model' with the name of your best model

## YOUR CODE HERE
# predictions_test <- predict(my_final_model, newdata = movies_test)


# 10. Create submission file ---------------------------------------------------

# Create a data frame with the required format: id and predicted_log_revenue

## YOUR CODE HERE
# submission <- data.frame(
#   id = movies_test$id,
#   predicted_log_revenue = predictions_test
# )

# Preview your submission
# head(submission)

# Check: Make sure you have predictions for all test movies
# stopifnot(nrow(submission) == nrow(movies_test))
# stopifnot(!any(is.na(submission$predicted_log_revenue)))

# Save to CSV file
# IMPORTANT: Use a unique filename with your name(s) to avoid confusion
# Format: predictions_TEAMNAME_i.csv
# where i denotes the ith submission from your team (you may make multiple)

## YOUR CODE HERE
# write.csv(submission, 
#           file = here("predictions_YOURNAME_1.csv"), 
#           row.names = FALSE)

# cat("\nSubmission file created! Submit 'predictions_YOURNAME_1.csv' to instructor by email.\n")


# 11. Submission instructions --------------------------------------------------

# DURING CLASS:
# 1. Save your predictions CSV file (format: predictions_YOURNAME_i.csv)
# 2. Email or share the CSV file with the instructor
# 3. Wait for your RMSE to be calculated and posted to the leaderboard
# 4. Iterate! Try a different model and submit again to improve your score
#
# AT END OF CLASS:
# 1. Submit your final R script (this file) on Moodle under Case Study 1 
#    Box Office Analysis (Part 4)
# 2. Your grade will be based on:
#    - Completeness of your code (10 points)
#    - Documentation and clarity (5 points)
#    - Prediction accuracy - top 3 pairs get bonus points (5 points)
#
# TIPS:
# - Start simple and iterate
# - Don't spend too long on any one model - try multiple approaches
# - Check your training RMSE to gauge model performance
# - Simpler models sometimes generalize better than complex ones
# - Have fun and be creative!

# Good luck!
