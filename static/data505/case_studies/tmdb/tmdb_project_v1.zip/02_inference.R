# 02_inference.R
# Name: 
# Date: 
# Drew University DATA 505 Fall 2025
#
# Assignment:
# Please complete the missing parts below, and submit your completed R script
# on Moodle under Case Study 1 Box Office Analysis (Part 2). This will be 
# graded and will be worth 20 points out of 70 total for the case study project.
#
# Purpose:
# - Run inferential analyses (confidence intervals and hypothesis tests) on 
#   random subsamples to answer practical questions. For example: What percent 
#   of films have you seen? What is average revenue? What is average user score? 
#   Does the average score differ between the US and Canada? How stable are 
#   these estimates across subsamples?
# - Gain a better understanding of confidence intervals and hypothesis tests 
#   through repeated sampling

# Table of contents
# 1. Load the cleaned data
# 2. (YOU) Take a random sample of 100 movies
# 3. (YOU) What proportion of movies have you seen?
# 4. (YOU) Confidence interval for mean revenue
# 5. (YOU) Repeated sampling / repeated confidence intervals

here::i_am("02_inference.R")
library(here)

# 1. Load the cleaned data -----------------------------------------------------

stopifnot(file.exists(here("data", "movies_clean.rds")))
movies <- readRDS(here("data", "movies_clean.rds"))


# 2. Take a random sample of 100 movies ----------------------------------------

# Hint: look at the sample() and slice() functions. Make sure the sample is
# taken *without replacement*.

## YOUR CODE HERE


# 3. What proportion of movies have you seen? ----------------------------------

# Look at the list of 100 randomly sampled movies. How many have you seen?
movies_seen <- NA_integer_ # replace with the number of movies you have seen out of 100
movies_sampled <- 100

# Based on this sample, provide a 95% confidence interval for the proportion of 
# all movies in TMDB do you have seen (among all films in TMDB which remain after
# the data cleaning steps in the 01_data.R script (non-missing information in 
# TMDB))

## YOUR CODE HERE

# Write the point estimate, and the upper and lower confidence bounds, on the
# white board. We will discuss the trends we see.


# 4. Confidence interval for mean revenue --------------------------------------

# Based on the same random sample, provide a confidence interval for the mean
# revenue among all films in TMDB.

## YOUR CODE HERE

# Write the point estimate, and the upper and lower confidence bounds, on the
# white board. We will discuss the trends we see.


# 5. Repeated sampling / repeated confidence intervals -------------------------

# 5.1 Write a function which takes as arguments (1) the full "movies" dataset, 
#     and (2) a sample size, and returns as output a random sample from the 
#     full dataset of a specified size. The body of the function may use similar
#.    code to what you wrote in part 2 above. We can discuss in class the function
#     syntax in R. You can also refer to: 
#     https://r4ds.hadley.nz/functions.html#writing-a-function

randomly_sample_movies <- function(movies, sample_size = 100){
  
  ## YOUR CODE HERE
  
}

# 5.2 Write a function which takes as an argument a single random sample from 
#     the full dataset, and returns a numeric vector with three elements in 
#     in order: (1) the sample mean revenue in the random sample, (2) the lower 
#     bound for a 95% confidence interval for the mean revenue based on the 
#     sample, and (3) the upper bound for a 95% confidence interval for the mean
#     revenue.

sample_based_inference <- function(movie_sample){
  
  ## YOUR CODE HERE
  
  return(c(
    sample_mean = NA_real_, # replace the NA with a variable defining the sample mean
    lower_bound = NA_real_, # replace the NA with a variable defining the lower confidence bound
    upper_bound = NA_real_
  ))
  
}

# 5.3 Write a "for" loop which repeatedly calls these two functions and stores
#     the sample-based estimates in a matrix.

# number of repeated samples
num_replicates <- 100

# set up a matrix to store the results
repeated_sample_results <- matrix(
  NA_real_,
  nrow = num_replicates,
  ncol = 3,
  dimnames = list(replicate = NULL,
                  statistic = c("sample_mean", "lower_bound", "upper_bound"))
)
str(repeated_sample_results)

for(rep in 1:num_replicates){
  
  ## YOUR CODE HERE
  
}

# 5.4 What is the actual mean revenue in the entire "movies" dataset? Store
#     this as a variable.

## YOUR CODE HERE

# 5.5 What proportion of the 100 confidence intervals you created contain this 
#     overall mean? What proportion would you expect to see here?

## YOUR CODE HERE

# 5.6 Create a plot with the replicates on the y-axis and the mean revenue on
#     the x-axis, with points at the sample mean for each estimate, and 
#     horizontal lines spanning from the lower confidence bound to the upper
#     confidence bound. Color these lines and points black if the CI contains
#     the overall mean, or red if the overall mean is outside the CI.

## YOUR CODE HERE

# When you are finished, submit this script on Moodle under Case Study 1 Box 
# Office Analysis (Part 2).