get_film_details_json <- function(movie_ids, 
                                  api_token) {
  
  library(httr2)
  library(purrr)
  
  base_url <- "https://api.themoviedb.org/3/movie"
  
  get_single_movie <- function(movie_id) {
    request(paste0(base_url, "/", movie_id, "?append_to_response=credits")) |>
      req_headers(
        Authorization = paste("Bearer", api_token),
        accept = "application/json"
      ) |>
      req_perform() |>
      resp_body_json()
  }
  
  # Make requests for all movie IDs with error handling
  cat("Querying API for details on", length(movie_ids), "movies...\n")
  map(movie_ids, safely(get_single_movie))
}

extract_individuals <- function(crew_list, job = c("Producer", "Director")) {
  
  if(!is.null(job)){
    job <- match.arg(job, several.ok = FALSE)
  }
  
  out_NA <- list(name = NA_character_, popularity = NA_real_)
  
  if (is.null(crew_list) || length(crew_list) == 0) return(out_NA)
  
  if(is.null(job)){
    job_crew <- crew_list
  } else{
    job_crew <- crew_list[map_lgl(crew_list, ~ .x$job == job)]
  }
  
  if (is.null(job_crew) || length(job_crew) == 0) return(out_NA)
  
  return(list(name = job_crew[[1]]$name,
              popularity = job_crew[[1]]$popularity))
}

get_film_details <- function(movie_ids, api_token){
  library(dplyr)
  library(tibble)
  
  # Get JSON responses
  json_results <- get_film_details_json(movie_ids, api_token = api_token)
  
  cat("Reforming results into a tabular dataset...\n")
  # Extract successful results and convert to tibble
  json_results |>
    map_dfr(~ {
      if (is.null(.x$error) && length(.x$result$production_companies)) {
        # Successfully retrieved data
        result <- .x$result
        
        # Extract credits
        director <- extract_individuals(result$credits$crew, "Director")
        producer <- extract_individuals(result$credits$crew, "Producer")
        actor <- extract_individuals(result$credits$cast, NULL)
        
        production_companies <- result$production_companies
        production_company <- ifelse(
          length(production_companies) > 0,
          production_companies[[1]]$name,
          NA_character_
        )
        production_company_origin_country <- ifelse(
          length(production_companies) > 0,
          production_companies[[1]]$origin_country,
          NA_character_
        )
        
        tibble(
          id = result$id %||% NA,
          title = result$title %||% NA,
          release_date = result$release_date %||% NA,
          budget = result$budget %||% NA,
          revenue = result$revenue %||% NA,
          runtime = result$runtime %||% NA,
          vote_average = result$vote_average %||% NA,
          vote_count = result$vote_count %||% NA,
          popularity = result$popularity %||% NA,
          overview = result$overview %||% NA,
          production_company = result$production_companies[[1]]$name,
          production_company_origin_country = result$production_companies[[1]]$origin_country,
          producer = producer$name,          
          director = director$name,
          director_popularity = !!director$popularity,
          actor = actor$name,
          actor_popularity = !!actor$popularity
        )
      } else {
        # API error - return row with NAs
        tibble(id = NA, title = NA, release_date = NA, budget = NA, 
               revenue = NA, runtime = NA, vote_average = NA, 
               vote_count = NA, popularity = NA, overview = NA,
               producer = NA, director = NA, director_popularity = NA,
               actor = NA, actor_popularity = NA)
      }
    })
}