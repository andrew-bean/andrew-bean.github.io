# 01_data.R
# Name: Solution
# Date: 
# Drew University DATA 505 Fall 2025
#
# Assignment:
# Please complete the missing parts below, and submit your completed R script
# on Moodle under Case Study 1 Box Office Analysis (Part 1). This will be 
# graded and will be worth 10 points out of 70 total for the case study project.
#
# Purpose:
# Gather data from the TMDB API about a sample of the most popular films on the
# platform. Format it, prepare it for analysis, and save the resulting clean
# dataset to disc in order to use it for subsequent analyses.

# Table of contents
# 1. (YOU) Provide your API token
# 2. Load libraries and functions
# 3. Obtain list of movie IDs
# 4. Get details from the API on each movie
# 5. (YOU) Clean the data and prepare it for analysis

here::i_am("01_data.R")
library(here)

# 1. (YOU) Provide your API token ----------------------------------------------

# YOU MUST DO THIS FIRST:
# You must create a file .env in the main project directory, following the 
# example provided in .env.example. It should define the API_KEY environment 
# variable based on the key from your TMDB account. Do not provide your key to 
# others, even your partner on the project (I recommend maintaining separate 
# accounts).

# Load environment variables from .env file if it exists
if (file.exists(here(".env"))) readRenviron(here(".env"))

# Use the API key
api_token <- Sys.getenv("API_KEY")

# Always check if the key exists
if (api_token == "") {
  stop("API_KEY not found in environment variables")
}

# 2. Load libraries and functions ----------------------------------------------

# if you are missing any of these packages, please install it first using
# install.packages().
suppressPackageStartupMessages({
  library(jsonlite)
  library(dplyr)
  library(purrr)
  library(tidyr)
  library(withr)
  library(lubridate)
  library(ggplot2)
})

# utility function to source multiple scripts. Comes from the example
# section of the reference page for the source() function. See ?source.
sourceDir <- function(path, trace = TRUE, ...) {
  op <- options(); on.exit(options(op)) # to reset after each
  for (nm in list.files(path, pattern = "[.][RrSsQq]$")) {
    if(trace) cat(nm,":")
    source(file.path(path, nm), ...)
    if(trace) cat("\n")
    options(op)
  }
}

# define several functions used to obtain and prepare the data
sourceDir(here("R"), trace = FALSE)

# 3. Obtain list of movie IDs --------------------------------------------------

raw_movie_list <- readRDS(here("data/movie_ids.rds"))

# 4. Get details from the API on each movie ------------------------------------

# this will take several minutes ...
film_details_raw <- get_film_details(raw_movie_list$id, api_token = api_token)
str(film_details_raw)

# 5. (YOU) Clean the data and prepare it for analysis --------------------------

# 5.1 Remove all rows with missing film name

film_details_clean <- film_details_raw |>
  filter(!is.na(title) & title != "")


# 5.2 Reformat release date. Use the ymd() function from lubridate to convert 
# the "release_date" column to a date class.

film_details_clean <- film_details_clean |>
  mutate(release_date = ymd(release_date))


# 5.3 Remove all rows where the "revenue" or "budget" column are missing or zero

film_details_clean <- film_details_clean |>
  filter(!is.na(revenue) & revenue > 0 & !is.na(budget) & budget > 0)


# 5.4 Remove all rows with missingness in the "actor_popularity" or
# "director_popularity" columns.

film_details_clean <- film_details_clean |>
  filter(!is.na(actor_popularity) & !is.na(director_popularity))


# 5.5 Create a new column "log_revenue" in the dataset to store the log 
# transformed revenue. 

film_details_clean <- film_details_clean |>
  mutate(log_revenue = log(revenue))


# 5.6 How many rows are remaining in the dataset?

nrow(film_details_clean)
cat("Number of rows remaining:", nrow(film_details_clean), "\n")


# 5.7 Use the saveRDS() function to save the cleaned dataset to a file
# named "data/movies_clean.rds". The filename is important, as the R scripts
# for parts 2 and 3 of the lab will begin by loading this file.

saveRDS(film_details_clean, here("data/movies_clean.rds"))
